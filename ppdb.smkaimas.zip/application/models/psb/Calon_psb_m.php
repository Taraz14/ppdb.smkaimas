<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Calon_psb_m extends CI_Model {


}

/* End of file Calon_psb_m.php */
