<?php

function gaskan($str){
    echo htmlentities($str, ENT_QUOTES, 'UTF-8');
}