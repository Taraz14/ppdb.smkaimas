</div>
<!-- /.content-wrapper -->
<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>Version</b> 2.0 Release
  </div>
  <strong>Copyright &copy; 2020 <a href="https://github.com/Taraz14" target="_blank ">DP</a>.</strong> All rights
  reserved.
</footer>