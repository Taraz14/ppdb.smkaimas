<!-- Main content -->
<section class="content">
   <h1>Data Siswa</h1>
</section>
