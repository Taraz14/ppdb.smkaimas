<?php defined('BASEPATH') OR exit('No direct script access allowed');

    // require('googlec8cdc9ec7568c583.html');
    require_once('headerScript.php');
    require_once('navbar.php');
    require_once('content.php');
    // require_once('footer.php');
    require_once('endScript.php');