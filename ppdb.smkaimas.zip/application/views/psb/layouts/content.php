<?php defined('BASEPATH') OR exit('No direct script access allowed');

if($content)
    $this->load->view($content);
    
