<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>



<!-- BOTTOM FOOTER -->
<section class="bottom-footer">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				Copyrights 2020 All Reseved by <a href="https://www.github.com/taraz14" target="_blank">D.Pradhana</a>
			</div>
			<div class="col-md-6 text-right">
				<a href="#">Terms of use</a>
				<a href="#">Privacy & Security Statement</a>
			</div>
		</div>
	</div>
</section>
<!-- END BOTTOM FOOTER -->